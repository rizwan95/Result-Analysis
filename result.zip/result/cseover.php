<html>
<head>
<title>Academic Performance Tracker</title>
 <a href="http://idroidwarz.com/result/frontpage/"><center><img src ="http://idroidwarz.com/demo/wp-content/uploads/2015/01/cropped-cropped-RMKCET1-e14217714014091.png"  ></center> <br></a>
<link rel="stylesheet" href="style.css">
<?php
 
 $servername = "localhost";
$username = "mradsens_iaw";
$password = "johncena9962";
$dbname = "mradsens_res";

// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysql_select_db("$dbname");

$res2 =  mysql_query("SELECT * from Secondyr");
$row2 = mysql_num_rows($res2);
$res2f =  mysql_query("SELECT * from Secondyr where MA6351 = 'U' OR CS6301 = 'U' OR CS6302 = 'U' OR CS6303 = 'U' OR CS6304 = 'U' OR CS6311 = 'U' OR CS6312 = 'U' OR GE6351 = 'U' ");
$row2f = mysql_num_rows($res2f);
$res2aper = (($row2f*100)/$row2);

$res4 =  mysql_query("SELECT * from Fourthyr");
$row4 = mysql_num_rows($res4);
$res4f =  mysql_query("SELECT * from Fourthyr where Regno <= 115 AND MG2452 = 'U' OR CS2401 = 'U' OR CS2402 = 'U' OR CS2403 = 'U' OR CS2405 = 'U' OR CS2406 = 'U' OR IT2024 = 'U' OR GE2022 = 'U'");
$row4f = mysql_num_rows($res4f);
$res4per = (($row4f*100)/$row4);



$res3 =  mysql_query("SELECT * from Thirdyr");
$row3 = mysql_num_rows($res3);
$res3f =  mysql_query("SELECT * from Thirdyr where MA2265 = 'U' OR CS2301 = 'U' OR CS2302 = 'U' OR CS2303 = 'U' OR CS2304 = 'U' OR CS2305 = 'U' OR CS2307 = 'U' OR CS2308 = 'U' OR CS2309 = 'U' ");
$row3f = mysql_num_rows($res3f);
$res3per = (($row3f*100)/$row3);

echo"<script type='text/javascript' src='fusioncharts/fusioncharts.js'></script>";
echo"<script type='text/javascript' src='fusioncharts/themes/fusioncharts.theme.fint.js'></script>";
echo"<script type='text/javascript'>";
echo"FusionCharts.ready(function () {";
echo"    var myChart = new FusionCharts({";
echo"      \"type\": \"pie3d\",";
echo"      \"renderAt\": \"chartContainer\",";
echo"      \"width\": \"500\",";
echo"      \"height\": \"300\",";
echo"      \"dataFormat\": \"xml\",";
echo"      \"dataSource\": \"<chart caption='Overall CSE Percentage' subcaption='Complete review of CSE' ><set label='II Year' value='",(100-$res2aper),"' /><set label='III Year' value='",(100-$res3per),"' /><set label='IV Year' value='",(100-$res4per),"' /></chart>\"});";
echo"  myChart.render();";
echo"});";
echo"</script>";
 ?>
 <style type="text/css">
 footer {
            background-color: #058599;
        color: #fff;
            width: 100%;
            bottom: 0;
            position: fixed;
        }
 </style>
</head>
<body>
<ul id="menu-bar">
 <li class="active"><a href="http://idroidwarz.com/result/frontpage/">Home</a></li>
 <li><a href="http://idroidwarz.com/result/frontpage/dept.php">Department</a>
  <ul>
   <li><a href="http://idroidwarz.com/result/cseover.php">CSE</a>
    <ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul>
   </li>
   <li><a href="http://idroidwarz.com/result/cseover.php">ECE</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">EEE</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">MECH</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">IT</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">S&H</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   
  </ul>
 </li>

 
</ul>

<h1 align="center">CSE Overall Performance<h1><br>
<table align="center">
<tr>
  <td><div id="chartContainer">FusionCharts XT will load here!</div> </td>
  <td>
<a href="http://idroidwarz.com/result/2.php" class="button"/>  II Year  </a> <br><br><br><br><br><br>

<a href="http://idroidwarz.com/result/3.php" class="button"/> III Year </a> <br><br><br><br><br><br>
<a href="http://idroidwarz.com/result/4.php" class="button"/>  IV Year  </a></td>

<center><footer>   Designed by Rizwan Ahmed , Sam Prasanna , Rohit Kumar   </footer></center>


</body>
</html>