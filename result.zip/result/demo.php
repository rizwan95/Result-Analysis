<?php

$servername = "localhost";
$username = "mradsens_iaw";
$password = "johncena9962";
$dbname = "mradsens_res";

// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysql_select_db("$dbname");


$sql = "SELECT * FROM Thirdyr";
$result =  mysql_query($sql);

echo "<table border ='1'>";
echo "<tr>";
echo "<th> Regno</th><th> Name</th><th> CS2301</th><th> CS2302</th><th> CS2303</th><th> CS2304</th><th> CS2305</th><th> CS2307</th><th> CS2308</th><th> CS2309</th><th> MA2265</th>";
echo "</tr>";

if($result === FALSE) { 
    die(mysql_error()); // TODO: better error handling
}

while( $row = mysql_fetch_array($result))
{

echo "<tr>";
echo "<td>", $row['Regno'], "</td> <td>","<td>", $row['Name'], "</td> <td>","<td>", $row['CS2301'], "</td> <td>","<td>", $row['CS2302'], "</td> <td>","<td>", $row['CS2303'], "</td> <td>","<td>", $row['CS2304'], "</td> <td>","<td>", $row['CS2305'], "</td> <td>","<td>", $row['CS2307'], "</td> <td>","<td>", $row['CS2308'], "</td> <td>","<td>", $row['CS2309'], "</td> <td>","<td>", $row['MA2265'], "</td>";
echo "</tr>";
 
}

echo "</table>";


mysql_close($conn);
?>