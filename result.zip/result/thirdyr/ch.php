<html>
<head>
<title>My First chart using FusionCharts Suite XT</title>
<script type="text/javascript" src="fusioncharts/fusioncharts.js"></script>
<script type="text/javascript" src="fusioncharts/themes/fusioncharts.theme.fint.js"></script>
<script type="text/javascript">
FusionCharts.ready(function () {
    var myChart = new FusionCharts({
      "type": "column3d",
      "renderAt": "chartContainer",
      "width": "500",
      "height": "300",
      "dataFormat": "xml",
      "dataSource": "<chart caption='III year CSE' subcaption='Complete review of III year CSE' xaxisname='Subjects' yaxisname='No. of failures' numberprefix='' palettecolors='#008ee4' bgalpha='0' borderalpha='20' canvasborderalpha='0' theme='fint' useplotgradientcolor='0' plotborderalpha='10' placevaluesinside='1' rotatevalues='1' valuefontcolor='#ffffff' captionpadding='20' showaxislines='1' axislinealpha='25' divlinealpha='10'><set label='CS2301' value='28' /><set label='CS2302' value='48' /><set label='CS2303' value='21' /><set label='CS2304' value='15' /><set label='CS2305' value='25' /><set label='CS2307' value='8' /><set label='CS2308' value='0' /><set label='CS2309' value='0' /><set label='MA2265' value='10' /></chart>"
    });

  myChart.render();
});
</script>

<script type="text/javascript">
FusionCharts.ready(function () {
    var myChart = new FusionCharts({
      "type": "column3d",
      "renderAt": "chartContainer1",
      "width": "500",
      "height": "300",
      "dataFormat": "xml",
      "dataSource": "<chart caption='III year CSE' subcaption='Complete review of III year CSE' xaxisname='Subjects' yaxisname='No. of failures' numberprefix='' palettecolors='#008ee4' bgalpha='0' borderalpha='20' canvasborderalpha='0' theme='fint' useplotgradientcolor='0' plotborderalpha='10' placevaluesinside='1' rotatevalues='1' valuefontcolor='#ffffff' captionpadding='20' showaxislines='1' axislinealpha='25' divlinealpha='10'><set label='CS2301' value='28' /><set label='CS2302' value='48' /><set label='CS2303' value='21' /><set label='CS2304' value='15' /><set label='CS2305' value='25' /><set label='CS2307' value='8' /><set label='CS2308' value='0' /><set label='CS2309' value='0' /><set label='MA2265' value='10' /></chart>"
    });

  myChart.render();
});
</script>

<script type="text/javascript">
FusionCharts.ready(function () {
    var myChart = new FusionCharts({
      "type": "column3d",
      "renderAt": "chartContainer2",
      "width": "500",
      "height": "300",
      "dataFormat": "xml",
      "dataSource": "<chart caption='III year CSE' subcaption='Complete review of III year CSE' xaxisname='Subjects' yaxisname='No. of failures' numberprefix='' palettecolors='#008ee4' bgalpha='0' borderalpha='20' canvasborderalpha='0' theme='fint' useplotgradientcolor='0' plotborderalpha='10' placevaluesinside='1' rotatevalues='1' valuefontcolor='#ffffff' captionpadding='20' showaxislines='1' axislinealpha='25' divlinealpha='10'><set label='CS2301' value='28' /><set label='CS2302' value='48' /><set label='CS2303' value='21' /><set label='CS2304' value='15' /><set label='CS2305' value='25' /><set label='CS2307' value='8' /><set label='CS2308' value='0' /><set label='CS2309' value='0' /><set label='MA2265' value='10' /></chart>"
    });

  myChart.render();
});
</script>
</head>
<body>
<table>
<tr>
  <td><div id="chartContainer">FusionCharts XT will load here!</div> </td>
  
  
  <td>  <div id="chartContainer1">FusionCharts XT will load here!</div></td>
  
  
  </tr>
  <tr>
  
  <td><div id="chartContainer2">FusionCharts XT will load here!</div> </td>
 
 
  <td><table><tr><th>CS2301</th><th>CS2302</th><th>CS2303</th><th>CS2304</th><th>CS2305</th><th>CS2307</th><th>CS2308</th><th>CS2309</th><th>MA2265</th></tr>
  <tr><td>100%</td><td>100%</td><td>100%</td><td>100%</td><td>100%</td><td>100%</td><td>100%</td><td>100%</td><td>100%</td></tr></table></td>
  
  
  </tr>
  </table>
</body>
</html>