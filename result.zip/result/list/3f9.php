<html>

<head><title>III year fail List </title>
<a href="http://idroidwarz.com/result/frontpage/"><center><img src ="http://idroidwarz.com/demo/wp-content/uploads/2015/01/cropped-cropped-RMKCET1-e14217714014091.png"  ></center> <br></a>
<style type="text/css">
 footer {
            background-color: #058599;
        color: #fff;
            width: 100%;
            bottom: 0;
            position: fixed;
        }
 </style>

</head>

<body>

<?php
 
 $servername = "localhost";
$username = "mradsens_iaw";
$password = "johncena9962";
$dbname = "mradsens_res";

// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysql_select_db("$dbname");


$result =  mysql_query("SELECT Regno,Name,Gender,DH,GM from Thirdyr WHERE MA2265 ='U' ");


echo"<center><h2> III year MA2265 failure list</h2></center>";
echo "<center><table border ='1'>";
echo"<tr>";
echo"<th>Regno</th><th>Name</th><th>Gender</th><th>D/H</th><th>G/M</th>";
echo"</tr>";

while($row=mysql_fetch_array($result))
{
echo"<tr>";
echo "<td>", $row['Regno'], "</td> <td>", $row['Name'], "</td> <td>", $row['Gender'], "</td> <td>", $row['DH'], "</td> <td>", $row['GM'], "</td>";

echo"</tr>";

}


echo"</table></center>";


echo"<center>";
$result =  mysql_query("SELECT Regno,Name,Gender,DH,GM from Thirdyr WHERE MA2265 !='U' ");


echo"<center><h2> II year MA2265  pass list</h2></center>";
echo "<center><table border ='1'>";
echo"<tr>";
echo"<th>Regno</th><th>Name</th><th>Gender</th><th>D/H</th><th>G/M</th>";
echo"</tr>";

while($row=mysql_fetch_array($result))
{
echo"<tr>";
echo "<td>", $row['Regno'], "</td> <td>", $row['Name'], "</td> <td>", $row['Gender'], "</td> <td>", $row['DH'], "</td> <td>", $row['GM'], "</td>";

echo"</tr>";

}


echo"</table></center>";






?>



<center><footer>   Designed by Rizwan Ahmed , Sam Prasanna , Rohit Kumar   </footer></center>
</body>
</html>