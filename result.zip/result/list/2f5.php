<html>

<head><title>II year section Fail List </title>
<a href="http://idroidwarz.com/result/frontpage/"><center><img src ="http://idroidwarz.com/demo/wp-content/uploads/2015/01/cropped-cropped-RMKCET1-e14217714014091.png"  ></center> <br></a>
<style type="text/css">
 footer {
            background-color: #058599;
        color: #fff;
            width: 100%;
            bottom: 0;
            position: fixed;
        }
 </style>
<link rel="stylesheet" href="style.css">
</head>

<body>
<ul id="menu-bar">
 <li class="active"><a href="http://idroidwarz.com/result/frontpage/">Home</a></li>
 <li><a href="http://idroidwarz.com/result/frontpage/dept.php">Department</a>
  <ul>
   <li><a href="http://idroidwarz.com/result/cseover.php">CSE</a>
    <ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul>
   </li>
   <li><a href="http://idroidwarz.com/result/cseover.php">ECE</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">EEE</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">MECH</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">IT</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">S&H</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   
  </ul>
 </li>

 
</ul>

<?php
 
 $servername = "localhost";
$username = "mradsens_iaw";
$password = "johncena9962";
$dbname = "mradsens_res";

// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysql_select_db("$dbname");


$result =  mysql_query("SELECT Regno,Name,Gender,DH,GM from Secondyr WHERE CS6311 ='U' ");


echo"<br><center><table><tr><td><center><h2> II year CS6311 failure list</h2></center></td>";


echo"<td><center><h2> II year CS6311 pass list</h2></center></td><td>&nbsp;&nbsp;&nbsp;&nbsp;<a href='http://idroidwarz.com/result/2.php' class='button'/> Back </a></td></tr>";


echo "<tr valign='top'><td><table border ='1' >";
echo"<tr>";
echo"<th>Regno</th><th>Name</th><th>Gender</th><th>D/H</th><th>G/M</th>";
echo"</tr>";

while($row=mysql_fetch_array($result))
{
echo"<tr>";
echo "<td>", $row['Regno'], "</td> <td>", $row['Name'], "</td> <td>", $row['Gender'], "</td> <td>", $row['DH'], "</td> <td>", $row['GM'], "</td>";

echo"</tr>";

}


echo"</table></td>";


$result =  mysql_query("SELECT Regno,Name,Gender,DH,GM from Secondyr WHERE CS6311 !='U' ");



echo "<td><table border ='1'>";
echo"<tr>";
echo"<th>Regno</th><th>Name</th><th>Gender</th><th>D/H</th><th>G/M</th>";
echo"</tr>";

while($row=mysql_fetch_array($result))
{
echo"<tr>";
echo "<td>", $row['Regno'], "</td> <td>", $row['Name'], "</td> <td>", $row['Gender'], "</td> <td>", $row['DH'], "</td> <td>", $row['GM'], "</td>";

echo"</tr>";

}


echo"</table>></td></tr></table></center>";




?>



<center><footer>   Designed by Rizwan Ahmed , Sam Prasanna , Rohit Kumar   </footer></center>
</body>
</html>