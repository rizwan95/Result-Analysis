<?php

$servername = "localhost";
$username = "mradsens_iaw";
$password = "johncena9962";
$dbname = "mradsens_res";

// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysql_select_db("$dbname");


$result =  mysql_query("SELECT * from Secondyr");
$row = mysql_num_rows($result);

// CS6301 fail percentage

$cs6301 = mysql_query("SELECT * from Secondyr WHERE CS6301 = 'U' AND Regno > 20");


$cs6301f= mysql_num_rows($cs6301);

$cs6301fper = (($cs6301f*100)/115);

// CS6302 fail percentage

$cs6302 = mysql_query("SELECT * from Secondyr WHERE CS6302 = 'U'");


$cs6302f= mysql_num_rows($cs6302);

$cs6302fper = (($cs6302f*100)/115);

// CS6303 fail percentage

$cs6303 = mysql_query("SELECT * from Secondyr WHERE CS6303 = 'U'");


$cs6303f= mysql_num_rows($cs6303);

$cs6303fper = (($cs6303f*100)/115);

// CS6304 fail percentage

$cs6304 = mysql_query("SELECT * from Secondyr WHERE CS6304 = 'U'");


$cs6304f= mysql_num_rows($cs6304);

$cs6304fper = (($cs6304f*100)/115);


//  fail percentage

$cs6311 = mysql_query("SELECT * from Secondyr WHERE CS6311 = 'U'");


$cs6311f= mysql_num_rows($cs6311);

$cs6311fper = (($cs6311f*100)/115);


// CS6312 fail percentage

$cs6312 = mysql_query("SELECT * from Secondyr WHERE CS6312 = 'U'");


$cs6312f= mysql_num_rows($cs6312);

$cs6312fper = (($cs6312f*100)/115);

// GE6351 fail percentage

$ge6351 = mysql_query("SELECT * from Secondyr WHERE GE6351 = 'U'");


$ge6351f= mysql_num_rows($ge6351);

$ge6351fper = (($ge6351f*100)/115);



// MA6351 fail percentage

$ma6351 = mysql_query("SELECT * from Secondyr WHERE MA6351 = 'U'");


$ma6351f= mysql_num_rows($ma6351);

$ma6351fper = (($ma6351f*100)/115);





echo "the number of students are ";
 
echo "$row <br> \n";

echo "The number of passed students in CS6301 are";
echo $row-$cs6301f ."<br>";

echo "the number of failuers in CS6301 are ";

echo "$cs6301f <br> ";


echo "The fail percentage in CS6301 is  ";

echo "$cs6301fper <br>";



echo "The number of passed students in CS6302 are";
echo $row-$cs6302f ."<br>";


echo "the number of failuers in CS6302 are ";

echo "$cs6302f <br> ";


echo "The fail percentage in CS6302 is  ";

echo "$cs6302fper <br>";


echo "The number of passed students in CS6303 are";
echo $row-$cs6303f ."<br>";

echo "the number of failuers in CS6303 are ";

echo "$cs6303f <br> ";


echo "The fail percentage in CS6303 is  ";

echo "$cs6303fper <br>";

echo "The number of passed students in CS6304 are";
echo $row-$cs6304f ."<br>";

echo "the number of failuers in CS6304 are ";

echo "$cs6304f <br> ";


echo "The fail percentage in CS2304 is  ";

echo "$cs6304fper <br>";


echo "The number of passed students in CS6311 are";
echo $row-$cs6311f ."<br>";

echo "the number of failuers in CS6311 are ";

echo "$cs6311f <br> ";


echo "The fail percentage in CS6311 is  ";

echo "$cs6311fper <br>";

echo "The number of passed students in CS6312 are";
echo $row-$cs6312f ."<br>";


echo "the number of failuers in CS6312 are ";

echo "$cs6312f <br> ";


echo "The fail percentage in CS6312 is  ";

echo "$cs6312fper <br>";


echo "The number of passed students in GE6351 are";
echo $row-$ge6351f ."<br>";

echo "the number of failuers in GE6351 are ";

echo "$ge6351f <br> ";


echo "The fail percentage in GE6351 is  ";

echo "$ge6351fper <br>";




echo "The number of passed students in MA6351 are";
echo $row-$ma6351f ."<br>";

echo "the number of failuers in MA6351 are ";

echo "$ma6351f <br> ";


echo "The fail percentage in MA6351 is  ";

echo "$ma6351fper <br>";



?>
        
        
        