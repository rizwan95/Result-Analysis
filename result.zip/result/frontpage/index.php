<html>
<head> <title>Academic Performance Tracker</title>
 <a href="http://idroidwarz.com/result/frontpage/"><center><img src ="http://idroidwarz.com/demo/wp-content/uploads/2015/01/cropped-cropped-RMKCET1-e14217714014091.png"  ></center> <br></a>
<link rel="stylesheet" href="style.css">
 <style type="text/css">
 footer {
            background-color: #058599;
        color: #fff;
            width: 100%;
            bottom: 0;
            position: fixed;
        }
 </style>
</head>
<body>


<ul id="menu-bar">
 <li class="active"><a href="http://idroidwarz.com/result/frontpage/">Home</a></li>
 <li><a href="http://idroidwarz.com/result/frontpage/dept.php">Department</a>
  <ul>
   <li><a href="http://idroidwarz.com/result/cseover.php">CSE</a>
    <ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul>
   </li>
   <li><a href="http://idroidwarz.com/result/cseover.php">ECE</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">EEE</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">MECH</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">IT</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">S&H</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   
  </ul>
 </li>

 
</ul>


<h1 align="center">Academic Performance Tracker</h1>
<center>

<br>


<a href="http://idroidwarz.com/result/frontpage/dept.php" class="button"/> UNIVERSITY EXAMINATION RESULTS </a> <br><br><br><br>

<a href="#" class="button"/> INTERNAL ASSESSMENT PERFORMANCE </a>


		
<center><footer>   Designed by Rizwan Ahmed , Sam Prasanna , Rohit Kumar   </footer></center>
		
		

</body>

</html>