<html>
<head>
<title>My First chart using FusionCharts Suite XT</title>
<?php
 
 $servername = "localhost";
$username = "mradsens_iaw";
$password = "johncena9962";
$dbname = "mradsens_res";

// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysql_select_db("$dbname");


$result =  mysql_query("SELECT * from Thirdyr WHERE Regno <=62");
$row = mysql_num_rows($result);

// CS2301 fail percentage

$CS2301 = mysql_query("SELECT * from Thirdyr WHERE CS2301 = 'U' AND Regno <=62");


$CS2301f= mysql_num_rows($CS2301);

$CS2301fper = (($CS2301f*100)/62);

// CS2302 fail percentage

$CS2302 = mysql_query("SELECT * from Thirdyr WHERE CS2302 = 'U' AND Regno <=62");


$CS2302f= mysql_num_rows($CS2302);

$CS2302fper = (($CS2302f*100)/62);

// CS2303 fail percentage

$CS2303 = mysql_query("SELECT * from Thirdyr WHERE CS2303 = 'U' AND Regno <=62");


$CS2303f= mysql_num_rows($CS2303);

$CS2303fper = (($CS2303f*100)/62);

// CS2305 fail percentage

$CS2305 = mysql_query("SELECT * from Thirdyr WHERE CS2305 = 'U' AND Regno <=62");


$CS2305f= mysql_num_rows($CS2305);

$CS2305fper = (($CS2305f*100)/62);


// CS2307 fail percentage

$CS2307 = mysql_query("SELECT * from Thirdyr WHERE CS2307 = 'U' AND Regno <=62");


$CS2307f= mysql_num_rows($CS2307);

$CS2307fper = (($CS2307f*100)/62);


// CS2308 fail percentage

$CS2308 = mysql_query("SELECT * from Thirdyr WHERE CS2308 = 'U' AND Regno < 62");


$CS2308f= mysql_num_rows($CS2308);

$CS2308fper = (($CS2308f*100)/62);


// CS2305 fail percentage

$CS2309 = mysql_query("SELECT * from Thirdyr WHERE CS2309 = 'U' AND Regno <=62");


$CS2309f= mysql_num_rows($CS2309);

$CS2309fper = (($CS2309f*100)/62);




// MA2265 fail percentage

$MA2265 = mysql_query("SELECT * from Thirdyr WHERE MA2265 = 'U' AND Regno <=62");


$MA2265f= mysql_num_rows($MA2265);

$MA2265fper = (($MA2265f*100)/62);

echo"<script type='text/javascript' src='fusioncharts/fusioncharts.js'></script>";
echo"<script type='text/javascript' src='fusioncharts/themes/fusioncharts.theme.fint.js'></script>";
echo"<script type='text/javascript'>";
echo"FusionCharts.ready(function () {";
echo"    var myChart = new FusionCharts({";
echo"      \"type\": \"column3d\",";
echo"      \"renderAt\": \"chartContainer1\",";
echo"      \"width\": \"500\",";
echo"      \"height\": \"300\",";
echo"      \"dataFormat\": \"xml\",";
echo"      \"dataSource\": \"<chart caption='III year CSE A analysis' subcaption='No. Pass of III year CSE A' xaxisname='Subjects' yaxisname='No. of Pass' numberprefix='' palettecolors='#008ee4' bgalpha='0' borderalpha='20' canvasborderalpha='0' theme='fint' useplotgradientcolor='0' plotborderalpha='10' placevaluesinside='1' rotatevalues='1' valuefontcolor='#ffffff' captionpadding='20' showaxislines='1' axislinealpha='25' divlinealpha='10'><set label='CS2301' value='",($row-$CS2301f),"' /><set label='CS2302' value='",($row-$CS2302f),"' /><set label='CS2303' value='",($row-$CS2303f),"' /><set label='CS2305' value='",($row-$CS2305f),"' /><set label='CS2307' value='",($row-$CS2307f),"' /><set label='IT2023' value='",($row-$CS2309f),"' /><set label='CS2309' value='",($row-$CS2309f),"' /><set label='MA2265' value='",($row-$MA2265f),"' /></chart>\"";
echo"    });";

echo"  myChart.render();";
echo"});";
echo"</script>";


echo"<script type='text/javascript' src='fusioncharts/fusioncharts.js'></script>";
echo"<script type='text/javascript' src='fusioncharts/themes/fusioncharts.theme.fint.js'></script>";
echo"<script type='text/javascript'>";
echo"FusionCharts.ready(function () {";
echo"    var myChart = new FusionCharts({";
echo"      \"type\": \"column3d\",";
echo"      \"renderAt\": \"chartContainer2\",";
echo"      \"width\": \"500\",";
echo"      \"height\": \"300\",";
echo"      \"dataFormat\": \"xml\",";
echo"      \"dataSource\": \"<chart caption='III year CSE A analysis' subcaption='No. Fail of III year CSE BA' xaxisname='Subjects' yaxisname='No. of Fail' numberprefix='' palettecolors='#008ee4' bgalpha='0' borderalpha='20' canvasborderalpha='0' theme='fint' useplotgradientcolor='0' plotborderalpha='10' placevaluesinside='1' rotatevalues='1' valuefontcolor='#ffffff' captionpadding='20' showaxislines='1' axislinealpha='25' divlinealpha='10'><set label='CS2301' value='",($CS2301f),"' /><set label='CS2302' value='",($CS2302f),"' /><set label='CS2303' value='",($CS2303f),"' /><set label='CS2305' value='",($CS2305f),"' /><set label='CS2307' value='",($CS2307f),"' /><set label='IT2023' value='",($CS2309f),"' /><set label='CS2309' value='",($CS2309f),"' /><set label='MA2265' value='",($MA2265f),"' /></chart>\"";
echo"    });";

echo"  myChart.render();";
echo"});";
echo"</script>";

$res3 =  mysql_query("SELECT * from Thirdyr");
$row3 = mysql_num_rows($res3);
$res3f =  mysql_query("SELECT * from Thirdyr where MA2265 = 'U' OR CS2301 = 'U' OR CS2302 = 'U' OR CS2303 = 'U' OR CS2304 = 'U' OR CS2305 = 'U' OR CS2307 = 'U' OR CS2308 = 'U' OR CS2309 = 'U'");
$row3f = mysql_num_rows($res3f);
$res3per = (($row3f*100)/$row3);

$total=$row3;
$tper=((($row3f)*100)/$total);



echo"<script type='text/javascript'>";
echo"FusionCharts.ready(function () {";
echo"    var myChart = new FusionCharts({";
echo"      \"type\": \"pie3d\",";
echo"      \"renderAt\": \"chartContainer3\",";
echo"      \"width\": \"500\",";
echo"      \"height\": \"300\",";
echo"      \"dataFormat\": \"xml\",";

echo"      \"dataSource\": \"<chart caption='Overall III CSE A Percentage' subcaption='Complete review of III CSE A' ><set label='Pass' value='",(100-$tper),"' /><set label='Fail' value='",($tper),"' /></chart>\"";
 echo"   });";

echo"  myChart.render();";
echo"});";
echo"</script>";
?>


</head>
<body>
<center><table>
<tr>
  <td><div id="chartContainer1">FusionCharts XT will load here!</div> </td>
  
  

  
  <td><div id="chartContainer2">FusionCharts XT will load here!</div> </td>  </tr>
</table><center>
 
 
  
 <center>  <div id="chartContainer3">FusionCharts XT will load here!</div></center>
 
 
 <?php
 
 $servername = "localhost";
$username = "mradsens_iaw";
$password = "johncena9962";
$dbname = "mradsens_res";

// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysql_select_db("$dbname");


$result =  mysql_query("SELECT * from Thirdyr WHERE Regno < 62");
$row = mysql_num_rows($result);

// CS2301 fail percentage

$cs2301 = mysql_query("SELECT * from Thirdyr WHERE CS2301 = 'U' AND Regno < 62");


$cs2301f= mysql_num_rows($cs2301);

$cs2301fper = (($cs2301f*100)/62);

// CS2302 fail percentage

$cs2302 = mysql_query("SELECT * from Thirdyr WHERE CS2302 = 'U' AND Regno < 62");


$cs2302f= mysql_num_rows($cs2302);

$cs2302fper = (($cs2302f*100)/62);

// CS2303 fail percentage

$cs2303 = mysql_query("SELECT * from Thirdyr WHERE CS2303 = 'U' AND Regno < 62");


$cs2303f= mysql_num_rows($cs2303);

$cs2303fper = (($cs2303f*100)/62);

// CS2304 fail percentage

$cs2304 = mysql_query("SELECT * from Thirdyr WHERE CS2304 = 'U' AND Regno < 62");


$cs2304f= mysql_num_rows($cs2304);

$cs2304fper = (($cs2304f*100)/62);


// CS2305 fail percentage

$cs2305 = mysql_query("SELECT * from Thirdyr WHERE CS2305 = 'U' AND Regno < 62");


$cs2305f= mysql_num_rows($cs2305);

$cs2305fper = (($cs2305f*100)/62);


// CS2307 fail percentage

$cs2307 = mysql_query("SELECT * from Thirdyr WHERE CS2307 = 'U' AND Regno < 62");


$cs2307f= mysql_num_rows($cs2307);

$cs2307fper = (($cs2307f*100)/62);

// CS2304 fail percentage

$cs2308 = mysql_query("SELECT * from Thirdyr WHERE CS2308 = 'U' AND Regno < 62");


$cs2308f= mysql_num_rows($cs2308);

$cs2308fper = (($cs2308f*100)/62);

// CS2309 fail percentage

$cs2309 = mysql_query("SELECT * from Thirdyr WHERE CS2309 = 'U' AND Regno < 62");


$cs2309f= mysql_num_rows($cs2309);

$cs2309fper = (($cs2309f*100)/62);


// MA2265 fail percentage

$ma2265 = mysql_query("SELECT * from Thirdyr WHERE MA2265 = 'U' AND Regno < 62");


$ma2265f= mysql_num_rows($ma2265);

$ma2265fper = (($ma2265f*100)/62);
 
 echo "The pass results are";
 
 echo "<table border='1'>";
 echo "<tr>";
 echo "<th>CS2301</th><th>CS2302</th><th>CS2303</th><th>CS2304</th><th>CS2305</th><th>CS2307</th><th>CS2308</th><th>CS2309</th><th>MA2265</th>"; echo "</tr>";
 
 echo "<tr>";
 echo "<td>",$row-$cs2301f,"</td><td>",$row-$cs2302f,"</td><td>",$row-$cs2303f,"</td><td>",$row-$cs2304f,"</td><td>",$row-$cs2305f,"</td><td>",$row-$cs2307f,"</td><td>",$row-$cs2308f,"</td><td>",$row-$cs2309f,"</td><td>",$row-$ma2265f,"</td>";
 echo "</tr>";
 echo "</table>";
 
 echo "The failure results are";
 
 echo "<table border='1'>";
 echo "<tr>";
 echo "<th>CS2301</th><th>CS2302</th><th>CS2303</th><th>CS2304</th><th>CS2305</th><th>CS2307</th><th>CS2308</th><th>CS2309</th><th>MA2265</th>"; echo "</tr>";
 
 echo "<tr>";
 echo "<td>",$cs2301f,"</td><td>",$cs2302f,"</td><td>",$cs2303f,"</td><td>",$cs2304f,"</td><td>",$cs2305f,"</td><td>",$cs2307f,"</td><td>",$cs2308f,"</td><td>",$cs2309f,"</td><td>",$ma2265f,"</td>";
 echo "</tr>";
 echo "</table>";
 
 
 
 
 
 ?>

</body>
</html>