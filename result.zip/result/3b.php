<html>
<head>
<title>Academic Performance Tracker</title>
<a href="http://idroidwarz.com/result/frontpage/"><center><img src ="http://idroidwarz.com/demo/wp-content/uploads/2015/01/cropped-cropped-RMKCET1-e14217714014091.png"  ></center> <br></a>
<style type="text/css">
 footer {
            background-color: #058599;
        color: #fff;
            width: 100%;
            bottom: 0;
            position: fixed;
        }
 </style>

<link rel="stylesheet" href="style.css">

<?php
 
 $servername = "localhost";
$username = "mradsens_iaw";
$password = "johncena9962";
$dbname = "mradsens_res";

// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysql_select_db("$dbname");


$result =  mysql_query("SELECT * from Thirdyr WHERE Regno > 62");
$row = mysql_num_rows($result);

// CS2301 fail percentage

$CS2301 = mysql_query("SELECT * from Thirdyr WHERE CS2301 = 'U' AND Regno > 62");


$CS2301f= mysql_num_rows($CS2301);

$CS2301fper = (($CS2301f*100)/70);

// CS2302 fail percentage

$CS2302 = mysql_query("SELECT * from Thirdyr WHERE CS2302 = 'U' AND Regno > 62");


$CS2302f= mysql_num_rows($CS2302);

$CS2302fper = (($CS2302f*100)/70);

// CS2303 fail percentage

$CS2303 = mysql_query("SELECT * from Thirdyr WHERE CS2303 = 'U' AND Regno > 62");


$CS2303f= mysql_num_rows($CS2303);

$CS2303fper = (($CS2303f*100)/70);

// CS2305 fail percentage

$CS2305 = mysql_query("SELECT * from Thirdyr WHERE CS2305 = 'U' AND Regno > 62");


$CS2305f= mysql_num_rows($CS2305);

$CS2305fper = (($CS2305f*100)/70);


// CS2307 fail percentage

$CS2307 = mysql_query("SELECT * from Thirdyr WHERE CS2307 = 'U' AND Regno > 62");


$CS2307f= mysql_num_rows($CS2307);

$CS2307fper = (($CS2307f*100)/70);


// CS2308 fail percentage

$CS2308 = mysql_query("SELECT * from Thirdyr WHERE CS2308 = 'U' AND Regno > 62");


$CS2308f= mysql_num_rows($CS2308);

$CS2308fper = (($CS2308f*100)/70);


// CS2305 fail percentage

$CS2309 = mysql_query("SELECT * from Thirdyr WHERE CS2309 = 'U' AND Regno > 62");


$CS2309f= mysql_num_rows($CS2309);

$CS2309fper = (($CS2309f*100)/70);




// MA2265 fail percentage

$MA2265 = mysql_query("SELECT * from Thirdyr WHERE MA2265 = 'U' AND Regno > 62");


$MA2265f= mysql_num_rows($MA2265);

$MA2265fper = (($MA2265f*100)/70);

echo"<script type='text/javascript' src='fusioncharts/fusioncharts.js'></script>";
echo"<script type='text/javascript' src='fusioncharts/themes/fusioncharts.theme.fint.js'></script>";
echo"<script type='text/javascript'>";
echo"FusionCharts.ready(function () {";
echo"    var myChart = new FusionCharts({";
echo"      \"type\": \"column3d\",";
echo"      \"renderAt\": \"chartContainer1\",";
echo"      \"width\": \"500\",";
echo"      \"height\": \"300\",";
echo"      \"dataFormat\": \"xml\",";
echo"      \"dataSource\": \"<chart caption='III year CSE B analysis' subcaption='No. Pass of III year CSE B' xaxisname='Subjects' yaxisname='No. of Pass' numberprefix='' palettecolors='#008ee4' bgalpha='0' borderalpha='20' canvasborderalpha='0' theme='fint' useplotgradientcolor='0' plotborderalpha='10' placevaluesinside='1' rotatevalues='1' valuefontcolor='#ffffff' captionpadding='20' showaxislines='1' axislinealpha='25' divlinealpha='10'><set label='CS2301' value='",($row-$CS2301f),"' /><set label='CS2302' value='",($row-$CS2302f),"' /><set label='CS2303' value='",($row-$CS2303f),"' /><set label='CS2305' value='",($row-$CS2305f),"' /><set label='CS2307' value='",($row-$CS2307f),"' /><set label='CS2308' value='",($row-$CS2308f),"' /><set label='CS2309' value='",($row-$CS2309f),"' /><set label='MA2265' value='",($row-$MA2265f),"' /></chart>\"";
echo"    });";

echo"  myChart.render();";
echo"});";
echo"</script>";


echo"<script type='text/javascript' src='fusioncharts/fusioncharts.js'></script>";
echo"<script type='text/javascript' src='fusioncharts/themes/fusioncharts.theme.fint.js'></script>";
echo"<script type='text/javascript'>";
echo"FusionCharts.ready(function () {";
echo"    var myChart = new FusionCharts({";
echo"      \"type\": \"column3d\",";
echo"      \"renderAt\": \"chartContainer2\",";
echo"      \"width\": \"500\",";
echo"      \"height\": \"300\",";
echo"      \"dataFormat\": \"xml\",";
echo"      \"dataSource\": \"<chart caption='III year CSE B analysis' subcaption='No. Fail of III year CSE B' xaxisname='Subjects' yaxisname='No. of Fail' numberprefix='' palettecolors='#008ee4' bgalpha='0' borderalpha='20' canvasborderalpha='0' theme='fint' useplotgradientcolor='0' plotborderalpha='10' placevaluesinside='1' rotatevalues='1' valuefontcolor='#ffffff' captionpadding='20' showaxislines='1' axislinealpha='25' divlinealpha='10'><set label='CS2301' value='",($CS2301f),"' /><set label='CS2302' value='",($CS2302f),"' /><set label='CS2303' value='",($CS2303f),"' /><set label='CS2305' value='",($CS2305f),"' /><set label='CS2307' value='",($CS2307f),"' /><set label='CS2308' value='",($CS2308f),"' /><set label='CS2309' value='",($CS2309f),"' /><set label='MA2265' value='",($MA2265f),"' /></chart>\"";
echo"    });";

echo"  myChart.render();";
echo"});";
echo"</script>";

$res3 =  mysql_query("SELECT * from Thirdyr");
$row3 = mysql_num_rows($res3);
$res3f =  mysql_query("SELECT * from Thirdyr where MA2265 = 'U' OR CS2301 = 'U' OR CS2302 = 'U' OR CS2303 = 'U' OR CS2304 = 'U' OR CS2305 = 'U' OR CS2307 = 'U' OR CS2308 = 'U' OR CS2309 = 'U'");
$row3f = mysql_num_rows($res3f);
$res3per = (($row3f*100)/$row3);

$total=$row3;
$tper=((($row3f)*100)/$total);



echo"<script type='text/javascript'>";
echo"FusionCharts.ready(function () {";
echo"    var myChart = new FusionCharts({";
echo"      \"type\": \"pie3d\",";
echo"      \"renderAt\": \"chartContainer3\",";
echo"      \"width\": \"500\",";
echo"      \"height\": \"300\",";
echo"      \"dataFormat\": \"xml\",";

echo"      \"dataSource\": \"<chart caption='Overall III CSE B Percentage' subcaption='Complete review of III CSE B' ><set label='Pass' value='",(100-$tper),"' /><set label='Fail' value='",($tper),"' /></chart>\"";
 echo"   });";

echo"  myChart.render();";
echo"});";
echo"</script>";
?>

</head>
<body>
<ul id="menu-bar">
 <li class="active"><a href="http://idroidwarz.com/result/frontpage/">Home</a></li>
 <li><a href="http://idroidwarz.com/result/frontpage/dept.php">Department</a>
  <ul>
   <li><a href="http://idroidwarz.com/result/cseover.php">CSE</a>
    <ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul>
   </li>
   <li><a href="http://idroidwarz.com/result/cseover.php">ECE</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">EEE</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">MECH</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">IT</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">S&H</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   
  </ul>
 </li>

 
</ul>

<center><table>
<tr>
  <td><div id="chartContainer1">FusionCharts XT will load here!</div> </td>
  
  

  
  <td><div id="chartContainer2">FusionCharts XT will load here!</div> </td>  </tr>
</table><center>
 
 
  
 <center>  <div id="chartContainer3">FusionCharts XT will load here!</div></center>
 
 
 <?php
 
 $servername = "localhost";
$username = "mradsens_iaw";
$password = "johncena9962";
$dbname = "mradsens_res";

// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysql_select_db("$dbname");


$result =  mysql_query("SELECT * from Thirdyr WHERE Regno > 62");
$row = mysql_num_rows($result);

// CS2301 fail percentage

$cs2301 = mysql_query("SELECT * from Thirdyr WHERE CS2301 = 'U' AND Regno > 62");


$cs2301f= mysql_num_rows($cs2301);

$cs2301fper = (($cs2301f*100)/70);

// CS2302 fail percentage

$cs2302 = mysql_query("SELECT * from Thirdyr WHERE CS2302 = 'U' AND Regno > 62");


$cs2302f= mysql_num_rows($cs2302);

$cs2302fper = (($cs2302f*100)/70);

// CS2303 fail percentage

$cs2303 = mysql_query("SELECT * from Thirdyr WHERE CS2303 = 'U' AND Regno > 62");


$cs2303f= mysql_num_rows($cs2303);

$cs2303fper = (($cs2303f*100)/70);

// CS2303 fail percentage

$cs2303 = mysql_query("SELECT * from Thirdyr WHERE CS2303 = 'U' AND Regno > 62");


$cs2303f= mysql_num_rows($cs2303);

$cs2303fper = (($cs2303f*100)/70);


// CS2305 fail percentage

$cs2305 = mysql_query("SELECT * from Thirdyr WHERE CS2305 = 'U' AND Regno > 62");


$cs2305f= mysql_num_rows($cs2305);

$cs2305fper = (($cs2305f*100)/70);


// CS2307 fail percentage

$cs2307 = mysql_query("SELECT * from Thirdyr WHERE CS2307 = 'U' AND Regno > 62");


$cs2307f= mysql_num_rows($cs2307);

$cs2307fper = (($cs2307f*100)/70);

// CS2303 fail percentage

$cs2308 = mysql_query("SELECT * from Thirdyr WHERE CS2308 = 'U' AND Regno > 62");


$cs2308f= mysql_num_rows($cs2308);

$cs2308fper = (($cs2308f*100)/70);

// CS2308 fail percentage

$CS2308 = mysql_query("SELECT * from Thirdyr WHERE CS2308 = 'U' AND Regno > 62");


$CS2308f= mysql_num_rows($CS2308);

$CS2308fper = (($CS2308f*100)/70);


// MA2265 fail percentage

$ma2265 = mysql_query("SELECT * from Thirdyr WHERE MA2265 = 'U' AND Regno > 62");


$ma2265f= mysql_num_rows($ma2265);

$ma2265fper = (($ma2265f*100)/70);


$CS2301fb = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2301 !='U'AND Gender = 'B'");
$CS2302fb = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2302 !='U'AND Gender = 'B'");
$CS2303fb = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2303 !='U'AND Gender = 'B'");
$CS2305fb = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2305 !='U'AND Gender = 'B'");
$CS2307fb = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2307 !='U'AND Gender = 'B'");
$CS2308fb = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2308 !='U'AND Gender = 'B'");
$CS2309fb = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2309 !='U'AND Gender = 'B'");
$MA2265fb = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND MA2265 !='U'AND Gender = 'B'");

$CS2301fg = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2301 !='U'AND Gender = 'G'");
$CS2302fg = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2302 !='U'AND Gender = 'G'");
$CS2303fg = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2303 !='U'AND Gender = 'G'");
$CS2305fg = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2305 !='U'AND Gender = 'G'");
$CS2307fg = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2307 !='U'AND Gender = 'G'");
$CS2308fg = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2308 !='U'AND Gender = 'G'");
$CS2309fg = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2309 !='U'AND Gender = 'G'");
$MA2265fg = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND MA2265 !='U'AND Gender = 'G'");

//COUNT OF BOYS PASSED
$cs2301cb = mysql_num_rows($CS2301fb);
$cs2302cb = mysql_num_rows($CS2302fb);
$cs2303cb = mysql_num_rows($CS2303fb);
$cs2305cb = mysql_num_rows($CS2305fb);
$cs2307cb = mysql_num_rows($CS2307fb);
$cs2308cb = mysql_num_rows($CS2308fb);
$cs2309cb = mysql_num_rows($CS2309fb);
$ma2265cb = mysql_num_rows($MA2265fb);

//COUNT OF GIRLS PASSED
$cs2301cg = mysql_num_rows($CS2301fg);
$cs2302cg = mysql_num_rows($CS2302fg);
$cs2303cg = mysql_num_rows($CS2303fg);
$cs2305cg = mysql_num_rows($CS2305fg);
$cs2307cg = mysql_num_rows($CS2307fg);
$cs2308cg = mysql_num_rows($CS2308fg);
$cs2309cg = mysql_num_rows($CS2309fg);
$ma2265cg = mysql_num_rows($MA2265fg); 

$CS2301ffd = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2301 !='U'AND DH = 'D'");
$CS2302ffd = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2302 !='U'AND DH = 'D'");
$CS2303ffd = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2303 !='U'AND DH = 'D'");
$CS2305ffd = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2305 !='U'AND DH = 'D'");
$CS2307ffd = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2307 !='U'AND DH = 'D'");
$CS2308ffd = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2308 !='U'AND DH = 'D'");
$CS2309ffd = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2309 !='U'AND DH = 'D'");
$MA2265ffd = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND MA2265 !='U'AND DH = 'D'");

$CS2301ffh = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2301 !='U'AND DH = 'H'");
$CS2302ffh = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2302 !='U'AND DH = 'H'");
$CS2303ffh = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2303 !='U'AND DH = 'H'");
$CS2305ffh = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2305 !='U'AND DH = 'H'");
$CS2307ffh = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2307 !='U'AND DH = 'H'");
$CS2308ffh = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2308 !='U'AND DH = 'H'");
$CS2309ffh = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND CS2309 !='U'AND DH = 'H'");
$MA2265ffh = mysql_query("SELECT * FROM Thirdyr WHERE Regno >62 AND MA2265 !='U'AND DH = 'H'");

//COUNT OF DAY PASSED
$cs2301cfd = mysql_num_rows($CS2301ffd);
$cs2302cfd = mysql_num_rows($CS2302ffd);
$cs2303cfd = mysql_num_rows($CS2303ffd);
$cs2305cfd = mysql_num_rows($CS2305ffd);
$cs2307cfd = mysql_num_rows($CS2307ffd);
$cs2308cfd = mysql_num_rows($CS2308ffd);
$cs2309cfd = mysql_num_rows($CS2309ffd);
$ma2265cfd = mysql_num_rows($MA2265ffd);

//COUNT OF HOSTEL PASSED
$cs2301cfh = mysql_num_rows($CS2301ffh);
$cs2302cfh = mysql_num_rows($CS2302ffh);
$cs2303cfh = mysql_num_rows($CS2303ffh);
$cs2305cfh = mysql_num_rows($CS2305ffh);
$cs2307cfh = mysql_num_rows($CS2307ffh);
$cs2308cfh = mysql_num_rows($CS2308ffh);
$cs2309cfh = mysql_num_rows($CS2309ffh);
$ma2265cfh = mysql_num_rows($MA2265ffh); 

 echo "<h3>No. Of Students Passed</h3>";
echo "<table>";
echo " <tr>";
 echo "<td>";
 echo "<table border='1'>";
 echo "<tr>";
 echo "<th colspan=2>CS2301</th><th colspan=2>CS2302</th><th colspan=2>CS2303</th><th colspan=2>CS2305</th><th 

colspan=2>CS2307</th><th colspan=2>CS2308</th><th colspan=2>CS2309</th><th colspan=2>MA2265</th>"; echo "</tr>";
 echo "<tr>";
 echo 

"<th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</

th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th>";
 echo "</tr>";
 echo "<tr>";
 echo "<td>",$cs2301cb,"</td><td>",$cs2301cg,"</td><td>",$cs2302cb,"</td><td>",$cs2302cg,"</td><td>",$cs2303cb,"</td><td>",$cs2303cg,"</td><td>",$cs2305cb,"</td><td>",$cs2305cg,"</td><td>",$cs2307cb,"</td><td>",$cs2307cg,"</td><td>",$cs2308cb,"</td><td>",$cs2308cg,"</td><td>",$cs2309cb,"</td><td>",$cs2309cg,"</td><td>",$ma2265cb,"</td><td>",$ma2265cg,"</td>";
 echo "</tr>";
 echo "</table>";
 echo "</td>";
 
 echo "<td>&nbsp&nbsp&nbsp&nbsp&nbsp</td>";

 echo "<td>";
 echo "<table border='1'>";
 echo "<tr>";
 echo "<th colspan=2>CS2301</th><th colspan=2>CS2302</th><th colspan=2>CS2303</th><th colspan=2>CS2305</th><th 

colspan=2>CS2307</th><th colspan=2>CS2308</th><th colspan=2>CS2309</th><th colspan=2>MA2265</th>"; echo "</tr>";
 echo "<tr>";
 echo 

"<th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</t

h><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th>";
 echo "</tr>";
 echo "<tr>";
 echo "<td>",$cs2301cfd,"</td><td>",$cs2301cfh,"</td><td>",$cs2302cfd,"</td><td>",$cs2302cfh,"</td><td>",$cs2303cfd,"</td><td>",$cs2303cfh,"</td><td>",$cs2305cfd,"</td><td>",$cs2305cfh,"</td><td>",$cs2307cfd,"</td><td>",$cs2307cfh,"</td><td>",$cs2308cfd,"</td><td>",$cs2308cfh,"</td><td>",$cs2309cfd,"</td><td>",$cs2309cfh,"</td><td>",$ma2265cfd,"</td><td>",$ma2265cfh,"</td>";
 echo "</tr>";
 echo "</table>";
 echo "</td>";
 echo "</tr>";
 echo "</table>";
 
 
 
 
 
 ?>
 <br><br><br>
 <a href="http://idroidwarz.com/result/3.php" class="button"/>  Back  </a> <br><br><br>

 
 <center><footer>   Designed by Rizwan Ahmed , Sam Prasanna , Rohit Kumar   </footer></center>


</body>
</html>