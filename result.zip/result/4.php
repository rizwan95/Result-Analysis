<html>
<head>
<title>Academic Performance Tracker</title>

<a href="http://idroidwarz.com/result/frontpage/"><center><img src ="http://idroidwarz.com/demo/wp-content/uploads/2015/01/cropped-cropped-RMKCET1-e14217714014091.png"  ></center> <br></a>
<style type="text/css">
 footer {
            background-color: #058599;
        color: #fff;
            width: 100%;
            bottom: 0;
            position: fixed;
        }
 </style>
<link rel="stylesheet" href="style.css">
 <?php
 
 $servername = "localhost";
$username = "mradsens_iaw";
$password = "johncena9962";
$dbname = "mradsens_res";

// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysql_select_db("$dbname");


$result =  mysql_query("SELECT * from Fourthyr WHERE Regno <= 115");
$row = mysql_num_rows($result);

// CS2401 fail percentage

$CS2401 = mysql_query("SELECT * from Fourthyr WHERE CS2401 = 'U' AND Regno <= 115");


$CS2401f= mysql_num_rows($CS2401);

$CS2401fper = (($CS2401f*100)/115);

// CS2402 fail percentage

$CS2402 = mysql_query("SELECT * from Fourthyr WHERE CS2402 = 'U' AND Regno <= 115");


$CS2402f= mysql_num_rows($CS2402);

$CS2402fper = (($CS2402f*100)/115);

// CS2403 fail percentage

$CS2403 = mysql_query("SELECT * from Fourthyr WHERE CS2403 = 'U' AND Regno <= 115");


$CS2403f= mysql_num_rows($CS2403);

$CS2403fper = (($CS2403f*100)/115);

// CS2405 fail percentage

$CS2405 = mysql_query("SELECT * from Fourthyr WHERE CS2405 = 'U' AND Regno <= 115");


$CS2405f= mysql_num_rows($CS2405);

$CS2405fper = (($CS2405f*100)/115);


// CS2406 fail percentage

$CS2406 = mysql_query("SELECT * from Fourthyr WHERE CS2406 = 'U' AND Regno <= 115");


$CS2406f= mysql_num_rows($CS2406);

$CS2406fper = (($CS2406f*100)/115);


// IT2024 fail percentage

$GE2022 = mysql_query("SELECT * from Fourthyr WHERE IT2024 = 'U' AND Regno <= 115");


$GE2022f= mysql_num_rows($GE2022);

$GE2022fper = (($GE2022f*100)/115);

// CS2405 fail percentage

$GE2022 = mysql_query("SELECT * from Fourthyr WHERE GE2022 = 'U' AND Regno <= 115");


$GE2022f= mysql_num_rows($GE2022);

$GE2022fper = (($GE2022f*100)/115);




// MG2452 fail percentage

$MG2452 = mysql_query("SELECT * from Fourthyr WHERE MG2452 = 'U' AND Regno <= 115");


$MG2452f= mysql_num_rows($MG2452);

$MG2452fper = (($MG2452f*100)/115);

echo"<script type='text/javascript' src='fusioncharts/fusioncharts.js'></script>";
echo"<script type='text/javascript' src='fusioncharts/themes/fusioncharts.theme.fint.js'></script>";
echo"<script type='text/javascript'>";
echo"FusionCharts.ready(function () {";
echo"    var myChart = new FusionCharts({";
echo"      \"type\": \"column3d\",";
echo"      \"renderAt\": \"chartContainer1\",";
echo"      \"width\": \"500\",";
echo"      \"height\": \"300\",";
echo"      \"dataFormat\": \"xml\",";
echo"      \"dataSource\": \"<chart caption='IV year CSE analysis' subcaption='No. Pass of IV year CSE' xaxisname='Subjects' yaxisname='No. of Pass' numberprefix='' palettecolors='#008ee4' bgalpha='0' borderalpha='20' canvasborderalpha='0' theme='fint' useplotgradientcolor='0' plotborderalpha='10' placevaluesinside='1' rotatevalues='1' valuefontcolor='#ffffff' captionpadding='20' showaxislines='1' axislinealpha='25' divlinealpha='10'><set label='CS2401' value='",($row-$CS2401f),"' /><set label='CS2402' value='",($row-$CS2402f),"' /><set label='CS2403' value='",($row-$CS2403f),"' /><set label='CS2405' value='",($row-$CS2405f),"' /><set label='CS2406' value='",($row-$CS2406f),"' /><set label='IT2024' value='",($row-$GE2022f),"' /><set label='GE2022' value='",($row-$GE2022f),"' /><set label='MG2452' value='",($row-$MG2452f),"' /></chart>\"";
echo"    });";

echo"  myChart.render();";
echo"});";
echo"</script>";


echo"<script type='text/javascript' src='fusioncharts/fusioncharts.js'></script>";
echo"<script type='text/javascript' src='fusioncharts/themes/fusioncharts.theme.fint.js'></script>";
echo"<script type='text/javascript'>";
echo"FusionCharts.ready(function () {";
echo"    var myChart = new FusionCharts({";
echo"      \"type\": \"column3d\",";
echo"      \"renderAt\": \"chartContainer2\",";
echo"      \"width\": \"500\",";
echo"      \"height\": \"300\",";
echo"      \"dataFormat\": \"xml\",";
echo"      \"dataSource\": \"<chart caption='IV year CSE analysis' subcaption='No. Fail of IV year CSE' xaxisname='Subjects' yaxisname='No. of Fail' numberprefix='' palettecolors='#008ee4' bgalpha='0' borderalpha='20' canvasborderalpha='0' theme='fint' useplotgradientcolor='0' plotborderalpha='10' placevaluesinside='1' rotatevalues='1' valuefontcolor='#ffffff' captionpadding='20' showaxislines='1' axislinealpha='25' divlinealpha='10'><set label='CS2401' value='",($CS2401f),"' /><set label='CS2402' value='",($CS2402f),"' /><set label='CS2403' value='",($CS2403f),"' /><set label='CS2405' value='",($CS2405f),"' /><set label='CS2406' value='",($CS2406f),"' /><set label='IT2024' value='",($GE2022f),"' /><set label='GE2022' value='",($GE2022f),"' /><set label='MG2452' value='",($MG2452f),"' /></chart>\"";
echo"    });";

echo"  myChart.render();";
echo"});";
echo"</script>";

$res4 =  mysql_query("SELECT * from Fourthyr");
$row4 = mysql_num_rows($res4);
$res4f =  mysql_query("SELECT * from Fourthyr where Regno <= 115 AND MG2452 = 'U' OR CS2401 = 'U' OR CS2402 = 'U' OR CS2403 = 'U' OR CS2405 = 'U' OR CS2406 = 'U' OR IT2024 = 'U' OR GE2022 = 'U'");
$row4f = mysql_num_rows($res4f);
$res4per = (($row4f*100)/$row4);

$total=$row4;
$tper=((($row4f)*100)/$total);



echo"<script type='text/javascript'>";
echo"FusionCharts.ready(function () {";
echo"    var myChart = new FusionCharts({";
echo"      \"type\": \"pie3d\",";
echo"      \"renderAt\": \"chartContainer3\",";
echo"      \"width\": \"500\",";
echo"      \"height\": \"300\",";
echo"      \"dataFormat\": \"xml\",";

echo"      \"dataSource\": \"<chart caption='Overall IV CSE Percentage' subcaption='Complete review of IV CSE' ><set label='Pass' value='",(100-$tper),"' /><set label='Fail' value='",($tper),"' /></chart>\"";
 echo"   });";

echo"  myChart.render();";
echo"});";
echo"</script>";
?>

</head>
<body>
<ul id="menu-bar">
 <li class="active"><a href="http://idroidwarz.com/result/frontpage/">Home</a></li>
 <li><a href="http://idroidwarz.com/result/frontpage/dept.php">Department</a>
  <ul>
   <li><a href="http://idroidwarz.com/result/cseover.php">CSE</a>
    <ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul>
   </li>
   <li><a href="http://idroidwarz.com/result/cseover.php">ECE</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">EEE</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">MECH</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">IT</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">S&H</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   
  </ul>
 </li>

 
</ul>

<center><table>
<tr>
  <td><div id="chartContainer1">FusionCharts XT will load here!</div> </td>
  
  

  
  <td><div id="chartContainer2">FusionCharts XT will load here!</div> </td>  </tr>
</table><center>
 
 
  
 <center>  <div id="chartContainer3">FusionCharts XT will load here!</div></center>
 
 
 <?php
 
 $servername = "localhost";
$username = "mradsens_iaw";
$password = "johncena9962";
$dbname = "mradsens_res";

// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysql_select_db("$dbname");


$result =  mysql_query("SELECT * from Fourthyr WHERE Regno <= 115");
$row = mysql_num_rows($result);

// CS2401 fail percentage

$CS2401 = mysql_query("SELECT * from Fourthyr WHERE CS2401 = 'U' AND Regno <= 115");


$CS2401f= mysql_num_rows($CS2401);

$CS2401fper = (($CS2401f*100)/115);

// CS2402 fail percentage

$CS2402 = mysql_query("SELECT * from Fourthyr WHERE CS2402 = 'U' AND Regno <= 115");


$CS2402f= mysql_num_rows($CS2402);

$CS2402fper = (($CS2402f*100)/115);

// CS2403 fail percentage

$CS2403 = mysql_query("SELECT * from Fourthyr WHERE CS2403 = 'U' AND Regno <= 115");


$CS2403f= mysql_num_rows($CS2403);

$CS2403fper = (($CS2403f*100)/115);

// CS2405 fail percentage

$CS2405 = mysql_query("SELECT * from Fourthyr WHERE CS2405 = 'U' AND Regno <= 115");


$CS2405f= mysql_num_rows($CS2405);

$CS2405fper = (($CS2405f*100)/115);


// CS2406 fail percentage

$CS2406 = mysql_query("SELECT * from Fourthyr WHERE CS2406 = 'U' AND Regno <= 115");


$CS2406f= mysql_num_rows($CS2406);

$CS2406fper = (($CS2406f*100)/115);


// IT2024 fail percentage

$GE2022 = mysql_query("SELECT * from Fourthyr WHERE IT2024 = 'U' AND Regno <= 115");


$GE2022f= mysql_num_rows($GE2022);

$GE2022fper = (($GE2022f*100)/115);

// CS2405 fail percentage

$GE2022 = mysql_query("SELECT * from Fourthyr WHERE GE2022 = 'U' AND Regno <= 115");


$GE2022f= mysql_num_rows($GE2022);

$GE2022fper = (($GE2022f*100)/115);




// MG2452 fail percentage

$MG2452 = mysql_query("SELECT * from Fourthyr WHERE MG2452 = 'U' AND Regno <= 115");


$MG2452f= mysql_num_rows($MG2452);

$MG2452fper = (($MG2452f*100)/115);
 
$CS2401fb = mysql_query("SELECT * FROM Fourthyr WHERE CS2401 !='U'AND Gender = 'B'");
$CS2402fb = mysql_query("SELECT * FROM Fourthyr WHERE CS2402 !='U'AND Gender = 'B'");
$CS2403fb = mysql_query("SELECT * FROM Fourthyr WHERE CS2403 !='U'AND Gender = 'B'");
$CS2405fb = mysql_query("SELECT * FROM Fourthyr WHERE CS2405 !='U'AND Gender = 'B'");
$CS2406fb = mysql_query("SELECT * FROM Fourthyr WHERE CS2406 !='U'AND Gender = 'B'");
$IT2024fb = mysql_query("SELECT * FROM Fourthyr WHERE IT2024 !='U'AND Gender = 'B'");
$MG2452fb = mysql_query("SELECT * FROM Fourthyr WHERE MG2452 !='U'AND Gender = 'B'");

$CS2401fg = mysql_query("SELECT * FROM Fourthyr WHERE CS2401 !='U'AND Gender = 'G'");
$CS2402fg = mysql_query("SELECT * FROM Fourthyr WHERE CS2402 !='U'AND Gender = 'G'");
$CS2403fg = mysql_query("SELECT * FROM Fourthyr WHERE CS2403 !='U'AND Gender = 'G'");
$CS2405fg = mysql_query("SELECT * FROM Fourthyr WHERE CS2405 !='U'AND Gender = 'G'");
$CS2406fg = mysql_query("SELECT * FROM Fourthyr WHERE CS2406 !='U'AND Gender = 'G'");
$IT2024fg = mysql_query("SELECT * FROM Fourthyr WHERE IT2024 !='U'AND Gender = 'G'");
$MG2452fg = mysql_query("SELECT * FROM Fourthyr WHERE MG2452 !='U'AND Gender = 'G'");

//COUNT OF BOYS PASSED
$CS2401cb = mysql_num_rows($CS2401fb);
$CS2402cb = mysql_num_rows($CS2402fb);
$CS2403cb = mysql_num_rows($CS2403fb);
$CS2405cb = mysql_num_rows($CS2405fb);
$CS2406cb = mysql_num_rows($CS2406fb);
$IT2024cb = mysql_num_rows($IT2024fb);
$MG2452cb = mysql_num_rows($MG2452fb);

//COUNT OF GIRLS PASSED
$CS2401cg = mysql_num_rows($CS2401fg);
$CS2402cg = mysql_num_rows($CS2402fg);
$CS2403cg = mysql_num_rows($CS2403fg);
$CS2405cg = mysql_num_rows($CS2405fg);
$CS2406cg = mysql_num_rows($CS2406fg);
$IT2024cg = mysql_num_rows($IT2024fg);
$MG2452cg = mysql_num_rows($MG2452fg); 

$CS2401ffd = mysql_query("SELECT * FROM Fourthyr WHERE CS2401 !='U'AND DH = 'D'");
$CS2402ffd = mysql_query("SELECT * FROM Fourthyr WHERE CS2402 !='U'AND DH = 'D'");
$CS2403ffd = mysql_query("SELECT * FROM Fourthyr WHERE CS2403 !='U'AND DH = 'D'");
$CS2405ffd = mysql_query("SELECT * FROM Fourthyr WHERE CS2405 !='U'AND DH = 'D'");
$CS2406ffd = mysql_query("SELECT * FROM Fourthyr WHERE CS2406 !='U'AND DH = 'D'");
$IT2024ffd = mysql_query("SELECT * FROM Fourthyr WHERE IT2024 !='U'AND DH = 'D'");
$MG2452ffd = mysql_query("SELECT * FROM Fourthyr WHERE MG2452 !='U'AND DH = 'D'");

$CS2401ffh = mysql_query("SELECT * FROM Fourthyr WHERE CS2401 !='U'AND DH = 'H'");
$CS2402ffh = mysql_query("SELECT * FROM Fourthyr WHERE CS2402 !='U'AND DH = 'H'");
$CS2403ffh = mysql_query("SELECT * FROM Fourthyr WHERE CS2403 !='U'AND DH = 'H'");
$CS2405ffh = mysql_query("SELECT * FROM Fourthyr WHERE CS2405 !='U'AND DH = 'H'");
$CS2406ffh = mysql_query("SELECT * FROM Fourthyr WHERE CS2406 !='U'AND DH = 'H'");
$IT2024ffh = mysql_query("SELECT * FROM Fourthyr WHERE IT2024 !='U'AND DH = 'H'");
$MG2452ffh = mysql_query("SELECT * FROM Fourthyr WHERE MG2452 !='U'AND DH = 'H'");

//COUNT OF DAY PASSED
$CS2401cfd = mysql_num_rows($CS2401ffd);
$CS2402cfd = mysql_num_rows($CS2402ffd);
$CS2403cfd = mysql_num_rows($CS2403ffd);
$CS2405cfd = mysql_num_rows($CS2405ffd);
$CS2406cfd = mysql_num_rows($CS2406ffd);
$IT2024cfd = mysql_num_rows($IT2024ffd);
$MG2452cfd = mysql_num_rows($MG2452ffd);

//COUNT OF HOSTEL PASSED
$CS2401cfh = mysql_num_rows($CS2401ffh);
$CS2402cfh = mysql_num_rows($CS2402ffh);
$CS2403cfh = mysql_num_rows($CS2403ffh);
$CS2405cfh = mysql_num_rows($CS2405ffh);
$CS2406cfh = mysql_num_rows($CS2406ffh);
$IT2024cfh = mysql_num_rows($IT2024ffh);
$MG2452cfh = mysql_num_rows($MG2452ffh); 

 echo "<h3>No. Of Students Passed</h3>";
echo "<table>";
echo " <tr>";
 echo "<td>";
 echo "<table border='1'>";
 echo "<tr>";
 echo "<th colspan=2><a href='http://idroidwarz.com/result/list/4f1.php' >CS2401</a></th><th colspan=2><a href='http://idroidwarz.com/result/list/4f2.php' >CS2402</a></th><th colspan=2><a href='http://idroidwarz.com/result/list/4f3.php' >CS2403</a></th><th colspan=2><a href='http://idroidwarz.com/result/list/4f4.php' >CS2405</a></th><th colspan=2><a href='http://idroidwarz.com/result/list/4f5.php' >CS2406</a></th><th colspan=2><a href='http://idroidwarz.com/result/list/4f6.php' >IT2024</a></th><th colspan=2><a href='http://idroidwarz.com/result/list/4f7.php' >MG2452</a></th>"; echo "</tr>";
 echo "<tr>";
 echo "<th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th>";
 echo "</tr>";
 echo "<tr>";
 echo "<td>",$CS2401cb,"</td><td>",$CS2401cg,"</td><td>",$CS2402cb,"</td><td>",$CS2402cg,"</td><td>",$CS2403cb,"</td><td>",$CS2403cg,"</td><td>",$CS2405cb,"</td><td>",$CS2405cg,"</td><td>",$CS2406cb,"</td><td>",$CS2406cg,"</td><td>",$IT2024cb,"</td><td>",$IT2024cg,"</td><td>",$MG2452cb,"</td><td>",$MG2452cg,"</td>";
 echo "</tr>";
 echo "</table>";
 echo "</td>";
 
 echo "<td>&nbsp&nbsp&nbsp&nbsp&nbsp</td>";

 echo "<td>";
 echo "<table border='1'>";
 echo "<tr>";
  echo "<th colspan=2><a href='http://idroidwarz.com/result/list/4f1.php' >CS2401</a></th><th colspan=2><a href='http://idroidwarz.com/result/list/4f2.php' >CS2402</a></th><th colspan=2><a href='http://idroidwarz.com/result/list/4f3.php' >CS2403</a></th><th colspan=2><a href='http://idroidwarz.com/result/list/4f4.php' >CS2405</a></th><th colspan=2><a href='http://idroidwarz.com/result/list/4f5.php' >CS2406</a></th><th colspan=2><a href='http://idroidwarz.com/result/list/4f6.php' >IT2024</a></th><th colspan=2><a href='http://idroidwarz.com/result/list/4f7.php' >MG2452</a></th>"; echo "</tr>";
 echo "<th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th>";
 echo "</tr>";
 echo "<tr>";
 echo "<td>",$CS2401cfd,"</td><td>",$CS2401cfh,"</td><td>",$CS2402cfd,"</td><td>",$CS2402cfh,"</td><td>",$CS2403cfd,"</td><td>",$CS2403cfh,"</td><td>",$CS2405cfd,"</td><td>",$CS2405cfh,"</td><td>",$CS2406cfd,"</td><td>",$CS2406cfh,"</td><td>",$IT2024cfd,"</td><td>",$IT2024cfh,"</td><td>",$MG2452cfd,"</td><td>",$MG2452cfh,"</td>";
 echo "</tr>";
 echo "</table>";
 echo "</td>";
 echo "</tr>";
 echo "</table>";
 
 
 
 ?>
 <center>
 <br><a href="http://idroidwarz.com/result/4a.php" class="button"/>  IV Year A Section  </a><br><br><br> <a href="http://idroidwarz.com/result/cseover.php" class="button"/>  Back  </a></center><br><br><br>
 
 
 <center><footer>   Designed by Rizwan Ahmed , Sam Prasanna , Rohit Kumar   </footer></center>


</body>
</html>