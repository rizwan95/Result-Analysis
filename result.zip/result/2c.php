<html>
<head>
<title>Academic Performance Tracker</title>
 <a href="http://idroidwarz.com/result/frontpage/"><center><img src ="http://idroidwarz.com/demo/wp-content/uploads/2015/01/cropped-cropped-RMKCET1-e14217714014091.png"  ></center> <br></a>

 <style type="text/css">
 footer {
            background-color: #058599;
        color: #fff;
            width: 100%;
            bottom: 0;
            position: fixed;
        }
 </style>

<link rel="stylesheet" href="style.css">
 <?php
 
 $servername = "localhost";
$username = "mradsens_iaw";
$password = "johncena9962";
$dbname = "mradsens_res";

// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysql_select_db("$dbname");


$result =  mysql_query("SELECT * from Secondyr WHERE Regno >76 ");
$row = mysql_num_rows($result);

// CS6301 fail percentage

$cs6301 = mysql_query("SELECT * from Secondyr WHERE CS6301 = 'U' AND Regno >76 ");


$cs6301f= mysql_num_rows($cs6301);

$cs6301fper = (($cs6301f*100)/38);

// CS6302 fail percentage

$cs6302 = mysql_query("SELECT * from Secondyr WHERE CS6302 = 'U' AND Regno >76 ");


$cs6302f= mysql_num_rows($cs6302);

$cs6302fper = (($cs6302f*100)/38);

// CS6303 fail percentage

$cs6303 = mysql_query("SELECT * from Secondyr WHERE CS6303 = 'U' AND Regno >76 ");


$cs6303f= mysql_num_rows($cs6303);

$cs6303fper = (($cs6303f*100)/38);

// CS6304 fail percentage

$cs6304 = mysql_query("SELECT * from Secondyr WHERE CS6304 = 'U' AND Regno >76 ");


$cs6304f= mysql_num_rows($cs6304);

$cs6304fper = (($cs6304f*100)/38);


// CS6311 fail percentage

$cs6311 = mysql_query("SELECT * from Secondyr WHERE CS6311 = 'U' AND Regno >76 ");


$cs6311f= mysql_num_rows($cs6311);

$cs6311fper = (($cs6311f*100)/38);


// CS6312 fail percentage

$cs6312 = mysql_query("SELECT * from Secondyr WHERE CS6312 = 'U' AND Regno >76 ");


$cs6312f= mysql_num_rows($cs6312);

$cs6312fper = (($cs6312f*100)/38);

// CS6304 fail percentage

$ge6351 = mysql_query("SELECT * from Secondyr WHERE GE6351 = 'U' AND Regno >76 ");


$ge6351f= mysql_num_rows($ge6351);

$ge6351fper = (($ge6351f*100)/38);




// MA6351 fail percentage

$ma6351 = mysql_query("SELECT * from Secondyr WHERE MA6351 = 'U' AND Regno >76 ");


$ma6351f= mysql_num_rows($ma6351);

$ma6351fper = (($ma6351f*100)/38);

echo"<script type='text/javascript' src='fusioncharts/fusioncharts.js'></script>";
echo"<script type='text/javascript' src='fusioncharts/themes/fusioncharts.theme.fint.js'></script>";
echo"<script type='text/javascript'>";
echo"FusionCharts.ready(function () {";
echo"    var myChart = new FusionCharts({";
echo"      \"type\": \"column3d\",";
echo"      \"renderAt\": \"chartContainer1\",";
echo"      \"width\": \"500\",";
echo"      \"height\": \"300\",";
echo"      \"dataFormat\": \"xml\",";
echo"      \"dataSource\": \"<chart caption='II year CSE C analysis' subcaption='No. Pass of II year CSE C ' xaxisname='Subjects' yaxisname='No. of Pass' numberprefix='' palettecolors='#008ee4' bgalpha='0' borderalpha='20' canvasborderalpha='0' theme='fint' useplotgradientcolor='0' plotborderalpha='10' placevaluesinside='1' rotatevalues='1' valuefontcolor='#ffffff' captionpadding='20' showaxislines='1' axislinealpha='25' divlinealpha='10'><set label='CS6301' value='",($row-$cs6301f),"' /><set label='CS6302' value='",($row-$cs6302f),"' /><set label='CS6303' value='",($row-$cs6303f),"' /><set label='CS6304' value='",($row-$cs6304f),"' /><set label='CS6311' value='",($row-$cs6311f),"' /><set label='CS6312' value='",($row-$cs6312f),"' /><set label='GE6351' value='",($row-$ge6351f),"' /><set label='MA6351' value='",($row-$ma6351f),"' /></chart>\"";
echo"    });";

echo"  myChart.render();";
echo"});";
echo"</script>";


echo"<script type='text/javascript' src='fusioncharts/fusioncharts.js'></script>";
echo"<script type='text/javascript' src='fusioncharts/themes/fusioncharts.theme.fint.js'></script>";
echo"<script type='text/javascript'>";
echo"FusionCharts.ready(function () {";
echo"    var myChart = new FusionCharts({";
echo"      \"type\": \"column3d\",";
echo"      \"renderAt\": \"chartContainer2\",";
echo"      \"width\": \"500\",";
echo"      \"height\": \"300\",";
echo"      \"dataFormat\": \"xml\",";
echo"      \"dataSource\": \"<chart caption='II year CSE C analysis' subcaption='No. Fail of II year CSE C ' xaxisname='Subjects' yaxisname='No. of Fail' numberprefix='' palettecolors='#008ee4' bgalpha='0' borderalpha='20' canvasborderalpha='0' theme='fint' useplotgradientcolor='0' plotborderalpha='10' placevaluesinside='1' rotatevalues='1' valuefontcolor='#ffffff' captionpadding='20' showaxislines='1' axislinealpha='25' divlinealpha='10'><set label='CS6301' value='",($cs6301f),"' /><set label='CS6302' value='",($cs6302f),"' /><set label='CS6303' value='",($cs6303f),"' /><set label='CS6304' value='",($cs6304f),"' /><set label='CS6311' value='",($cs6311f),"' /><set label='CS6312' value='",($cs6312f),"' /><set label='GE6351' value='",($ge6351f),"' /><set label='MA6351' value='",($ma6351f),"' /></chart>\"";
echo"    });";

echo"  myChart.render();";
echo"});";
echo"</script>";

$res2a =  mysql_query("SELECT * from Secondyr where Regno >76");
$row2a = mysql_num_rows($res2a);
$res2af =  mysql_query("SELECT * from Secondyr where Regno >76  AND MA6351 = 'U' OR CS6301 = 'U' OR CS6302 = 'U' OR CS6303 = 'U' OR CS6304 = 'U' OR CS6311 = 'U' OR CS6312 = 'U' OR GE6351 = 'U'");
$row2af = mysql_num_rows($res2af);
$res2aper = (($row2af*100)/$row2a);

$total=$row2a;
$tper=((($row2af)*100)/$total);



echo"<script type='text/javascript'>";
echo"FusionCharts.ready(function () {";
echo"    var myChart = new FusionCharts({";
echo"      \"type\": \"pie3d\",";
echo"      \"renderAt\": \"chartContainer3\",";
echo"      \"width\": \"500\",";
echo"      \"height\": \"300\",";
echo"      \"dataFormat\": \"xml\",";

echo"      \"dataSource\": \"<chart caption='Overall CSE C Percentage' subcaption='Complete review of CSE C' ><set label='Pass' value='",($tper),"' /><set label='Fail' value='",(100-$tper),"' /></chart>\"";
 echo"   });";

echo"  myChart.render();";
echo"});";
echo"</script>";
?>

</head>
<body>
<ul id="menu-bar">
 <li class="active"><a href="http://idroidwarz.com/result/frontpage/">Home</a></li>
 <li><a href="http://idroidwarz.com/result/frontpage/dept.php">Department</a>
  <ul>
   <li><a href="http://idroidwarz.com/result/cseover.php">CSE</a>
    <ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul>
   </li>
   <li><a href="http://idroidwarz.com/result/cseover.php">ECE</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">EEE</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">MECH</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">IT</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   <li><a href="http://idroidwarz.com/result/cseover.php">S&H</a><ul>
     <li><a href="http://idroidwarz.com/result/2.php" >II Year</a> </li>
     <li><a href="http://idroidwarz.com/result/3.php" >III Year</a> </li>
     <li><a href="http://idroidwarz.com/result/4.php" >IV Year</a></li>
    </ul></li>
   
  </ul>
 </li>

 
</ul>

<center><table>
<tr>
  <td><div id="chartContainer1">FusionCharts XT will load here!</div> </td>
  
  

  
  <td><div id="chartContainer2">FusionCharts XT will load here!</div> </td>  </tr>
</table><center>
 
 
  
 <center>  <div id="chartContainer3">FusionCharts XT will load here!</div></center>
 
 
 <?php
 
 $servername = "localhost";
$username = "mradsens_iaw";
$password = "johncena9962";
$dbname = "mradsens_res";

// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysql_select_db("$dbname");


$result =  mysql_query("SELECT * from Secondyr WHERE Regno >76 ");
$row = mysql_num_rows($result);

// CS6301 fail percentage

$cs6301 = mysql_query("SELECT * from Secondyr WHERE CS6301 = 'U' AND Regno >76 ");


$cs6301f= mysql_num_rows($cs6301);

$cs6301fper = (($cs6301f*100)/38);

// CS6302 fail percentage

$cs6302 = mysql_query("SELECT * from Secondyr WHERE CS6302 = 'U' AND Regno >76 ");


$cs6302f= mysql_num_rows($cs6302);

$cs6302fper = (($cs6302f*100)/38);

// CS6303 fail percentage

$cs6303 = mysql_query("SELECT * from Secondyr WHERE CS6303 = 'U' AND Regno >76 ");


$cs6303f= mysql_num_rows($cs6303);

$cs6303fper = (($cs6303f*100)/38);

// CS6304 fail percentage

$cs6304 = mysql_query("SELECT * from Secondyr WHERE CS6304 = 'U' AND Regno >76 ");


$cs6304f= mysql_num_rows($cs6304);

$cs6304fper = (($cs6304f*100)/38);


// CS6311 fail percentage

$cs6311 = mysql_query("SELECT * from Secondyr WHERE CS6311 = 'U' AND Regno >76 ");


$cs6311f= mysql_num_rows($cs6311);

$cs6311fper = (($cs6311f*100)/38);


// CS6312 fail percentage

$cs6312 = mysql_query("SELECT * from Secondyr WHERE CS6312 = 'U' AND Regno >76 ");


$cs6312f= mysql_num_rows($cs6312);

$cs6312fper = (($cs6312f*100)/38);

// CS6304 fail percentage

$ge6351 = mysql_query("SELECT * from Secondyr WHERE GE6351 = 'U' AND Regno >76 ");


$ge6351f= mysql_num_rows($ge6351);

$ge6351fper = (($ge6351f*100)/38);




// MA6351 fail percentage

$ma6351 = mysql_query("SELECT * from Secondyr WHERE MA6351 = 'U' AND Regno >76 ");


$ma6351f= mysql_num_rows($ma6351);

$ma6351fper = (($ma6351f*100)/38);
 
$CS6301fb = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6301 !='U'AND Gender = 'B'");
$CS6302fb = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6302 !='U'AND Gender = 'B'");
$CS6303fb = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6303 !='U'AND Gender = 'B'");
$CS6304fb = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6304 !='U'AND Gender = 'B'");
$CS6311fb = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6311 !='U'AND Gender = 'B'");
$CS6312fb = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6312 !='U'AND Gender = 'B'");
$GE6351fb = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  GE6351 !='U'AND Gender = 'B'");
$MA6351fb = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  MA6351 !='U'AND Gender = 'B'");

$CS6301fg = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6301 !='U'AND Gender = 'G'");
$CS6302fg = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6302 !='U'AND Gender = 'G'");
$CS6303fg = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6303 !='U'AND Gender = 'G'");
$CS6304fg = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6304 !='U'AND Gender = 'G'");
$CS6311fg = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6311 !='U'AND Gender = 'G'");
$CS6312fg = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6312 !='U'AND Gender = 'G'");
$GE6351fg = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  GE6351 !='U'AND Gender = 'G'");
$MA6351fg = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  MA6351 !='U'AND Gender = 'G'");

//COUNT OF BOYS PASSED
$CS6301cb = mysql_num_rows($CS6301fb);
$CS6302cb = mysql_num_rows($CS6302fb);
$CS6303cb = mysql_num_rows($CS6303fb);
$CS6304cb = mysql_num_rows($CS6304fb);
$CS6311cb = mysql_num_rows($CS6311fb);
$CS6312cb = mysql_num_rows($CS6312fb);
$GE6351cb = mysql_num_rows($GE6351fb);
$MA6351cb = mysql_num_rows($MA6351fb);

//COUNT OF GIRLS PASSED
$CS6301cg = mysql_num_rows($CS6301fg);
$CS6302cg = mysql_num_rows($CS6302fg);
$CS6303cg = mysql_num_rows($CS6303fg);
$CS6304cg = mysql_num_rows($CS6304fg);
$CS6311cg = mysql_num_rows($CS6311fg);
$CS6312cg = mysql_num_rows($CS6312fg);
$GE6351cg = mysql_num_rows($GE6351fg); 
$MA6351cg = mysql_num_rows($MA6351fg); 

$CS6301ffd = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6301 !='U'AND DH = 'D'");
$CS6302ffd = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6302 !='U'AND DH = 'D'");
$CS6303ffd = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6303 !='U'AND DH = 'D'");
$CS6304ffd = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6304 !='U'AND DH = 'D'");
$CS6311ffd = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6311 !='U'AND DH = 'D'");
$CS6312ffd = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6312 !='U'AND DH = 'D'");
$GE6351ffd = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  GE6351 !='U'AND DH = 'D'");
$MA6351ffd = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  MA6351 !='U'AND DH = 'D'");

$CS6301ffh = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6301 !='U'AND DH = 'H'");
$CS6302ffh = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6302 !='U'AND DH = 'H'");
$CS6303ffh = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6303 !='U'AND DH = 'H'");
$CS6304ffh = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6304 !='U'AND DH = 'H'");
$CS6311ffh = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6311 !='U'AND DH = 'H'");
$CS6312ffh = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  CS6312 !='U'AND DH = 'H'");
$GE6351ffh = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  GE6351 !='U'AND DH = 'H'");
$MA6351ffh = mysql_query("SELECT * FROM Secondyr WHERE Regno >76 AND  MA6351 !='U'AND DH = 'H'");

//COUNT OF DAY PASSED
$CS6301cfd = mysql_num_rows($CS6301ffd);
$CS6302cfd = mysql_num_rows($CS6302ffd);
$CS6303cfd = mysql_num_rows($CS6303ffd);
$CS6304cfd = mysql_num_rows($CS6304ffd);
$CS6311cfd = mysql_num_rows($CS6311ffd);
$CS6312cfd = mysql_num_rows($CS6312ffd);
$GE6351cfd = mysql_num_rows($GE6351ffd);
$MA6351cfd = mysql_num_rows($MA6351ffd);

//COUNT OF HOSTEL PASSED
$CS6301cfh = mysql_num_rows($CS6301ffh);
$CS6302cfh = mysql_num_rows($CS6302ffh);
$CS6303cfh = mysql_num_rows($CS6303ffh);
$CS6304cfh = mysql_num_rows($CS6304ffh);
$CS6311cfh = mysql_num_rows($CS6311ffh);
$CS6312cfh = mysql_num_rows($CS6312ffh);
$GE6351cfh = mysql_num_rows($GE6351ffh); 
$MA6351cfh = mysql_num_rows($MA6351ffh); 

 echo "<h3>No. Of Students Passed</h3>";
echo "<table>";
echo " <tr>";
 echo "<td>";
 echo "<table border='1'>";
 echo "<tr>";
 echo "<th colspan=2>CS6301</th><th colspan=2>CS6302</th><th colspan=2>CS6303</th><th colspan=2>CS6304</th><th colspan=2>CS6311</th><th colspan=2>CS6312</th><th colspan=2>GE6351</th><th colspan=2>MA6351</th>";
  echo "</tr>";
 echo "<tr>";
 echo "<th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th><th>Boys</th><th>Girls</th>";
 echo "</tr>";
 echo "<tr>";
 echo "<td>",$CS6301cb,"</td><td>",$CS6301cg,"</td><td>",$CS6302cb,"</td><td>",$CS6302cg,"</td><td>",$CS6303cb,"</td><td>",$CS6303cg,"</td><td>",$CS6304cb,"</td><td>",$CS6304cg,"</td><td>",$CS6311cb,"</td><td>",$CS6311cg,"</td><td>",$CS6312cb,"</td><td>",$CS6312cg,"</td><td>",$GE6351cb,"</td><td>",$GE6351cg,"</td><td>",$MA6351cb,"</td><td>",$MA6351cg,"</td>";
 echo "</tr>";
 echo "</table>";
 echo "</td>";
 
 echo "<td>&nbsp&nbsp&nbsp&nbsp&nbsp</td>";

 echo "<td>";
 echo "<table border='1'>";
 echo "<tr>";
 echo "<th colspan=2>CS6301</th><th colspan=2>CS6302</th><th colspan=2>CS6303</th><th colspan=2>CS6304</th><th colspan=2>CS6311</th><th colspan=2>CS6312</th><th colspan=2>GE6351</th><th colspan=2>MA6351</th>";
  echo "</tr>";
 echo "<tr>";
 echo "<th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th><th>Day</th><th>Hostel</th>";
 echo "</tr>";
 echo "<tr>";
 echo "<td>",$CS6301cfd,"</td><td>",$CS6301cfh,"</td><td>",$CS6302cfd,"</td><td>",$CS6302cfh,"</td><td>",$CS6303cfd,"</td><td>",$CS6303cfh,"</td><td>",$CS6304cfd,"</td><td>",$CS6304cfh,"</td><td>",$CS6311cfd,"</td><td>",$CS6311cfh,"</td><td>",$CS6312cfd,"</td><td>",$CS6312cfh,"</td><td>",$GE6351cfd,"</td><td>",$GE6351cfh,"</td><td>",$MA6351cfd,"</td><td>",$MA6351cfh,"</td>";
 echo "</tr>";
 echo "</table>";
 echo "</td>";
 echo "</tr>";
 echo "</table>";

 
 
 
 
 
 ?>
 <br> <br> <br>
 <a href="http://idroidwarz.com/result/2.php" class="button"/>  Back  </a><br><br><br>
 
 <center><footer>   Designed by Rizwan Ahmed , Sam Prasanna , Rohit Kumar   </footer></center>


</body>
</html>