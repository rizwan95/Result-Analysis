<html>
<head>
<title>My First chart using FusionCharts Suite XT</title>
<script type="text/javascript" src="fusioncharts/fusioncharts.js"></script>
<script type="text/javascript" src="fusioncharts/themes/fusioncharts.theme.fint.js"></script>
<script type="text/javascript">
FusionCharts.ready(function () {
    var myChart = new FusionCharts({
      "type": "column3d",
      "renderAt": "chartContainer",
      "width": "500",
      "height": "300",
      "dataFormat": "xml",
      "dataSource": "<chart caption='II year CSE A analysis' subcaption='Pass percentage of II year CSE A ' xaxisname='Subjects' yaxisname='No. of failures' numberprefix='' palettecolors='#008ee4' bgalpha='0' borderalpha='20' canvasborderalpha='0' theme='fint' useplotgradientcolor='0' plotborderalpha='10' placevaluesinside='1' rotatevalues='1' valuefontcolor='#ffffff' captionpadding='20' showaxislines='1' axislinealpha='25' divlinealpha='10'><set label='CS2301' value='28' /><set label='CS2302' value='48' /><set label='CS2303' value='21' /><set label='CS2304' value='15' /><set label='CS2305' value='25' /><set label='CS2307' value='8' /><set label='CS2308' value='0' /><set label='CS2309' value='0' /><set label='MA2265' value='10' /></chart>"
    });

  myChart.render();
});
</script>

<script type="text/javascript">
FusionCharts.ready(function () {
    var myChart = new FusionCharts({
      "type": "column3d",
      "renderAt": "chartContainer1",
      "width": "500",
      "height": "300",
      "dataFormat": "xml",
      "dataSource": "<chart caption='III year CSE A analysis' subcaption='Fail percentage of III year CSE A' xaxisname='Subjects' yaxisname='No. of failures' numberprefix='' palettecolors='#008ee4' bgalpha='0' borderalpha='20' canvasborderalpha='0' theme='fint' useplotgradientcolor='0' plotborderalpha='10' placevaluesinside='1' rotatevalues='1' valuefontcolor='#ffffff' captionpadding='20' showaxislines='1' axislinealpha='25' divlinealpha='10'><set label='CS2301' value='28' /><set label='CS2302' value='48' /><set label='CS2303' value='21' /><set label='CS2304' value='15' /><set label='CS2305' value='25' /><set label='CS2307' value='8' /><set label='CS2308' value='0' /><set label='CS2309' value='0' /><set label='MA2265' value='10' /></chart>"
    });

  myChart.render();
});
</script>

<script type="text/javascript">
FusionCharts.ready(function () {
    var myChart = new FusionCharts({
      "type": "column3d",
      "renderAt": "chartContainer2",
      "width": "500",
      "height": "300",
      "dataFormat": "xml",
      "dataSource": "<chart caption='III year CSE A analysis' subcaption='Overall performance of CSE A' xaxisname='Subjects' yaxisname='No. of failures' numberprefix='' palettecolors='#008ee4' bgalpha='0' borderalpha='20' canvasborderalpha='0' theme='fint' useplotgradientcolor='0' plotborderalpha='10' placevaluesinside='1' rotatevalues='1' valuefontcolor='#ffffff' captionpadding='20' showaxislines='1' axislinealpha='25' divlinealpha='10'><set label='CS2301' value='28' /><set label='CS2302' value='48' /><set label='CS2303' value='21' /><set label='CS2304' value='15' /><set label='CS2305' value='25' /><set label='CS2307' value='8' /><set label='CS2308' value='0' /><set label='CS2309' value='0' /><set label='MA2265' value='10' /></chart>"
    });

  myChart.render();
});
</script>
</head>
<body>
<center><table>
<tr>
  <td><div id="chartContainer">FusionCharts XT will load here!</div> </td>
  
  

  
  <td><div id="chartContainer2">FusionCharts XT will load here!</div> </td>  </tr>
</table><center>
 
 
  
 <center>  <div id="chartContainer1">FusionCharts XT will load here!</div></center>
 
 
 <?php
 
 $servername = "localhost";
$username = "mradsens_iaw";
$password = "johncena9962";
$dbname = "mradsens_res";

// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysql_select_db("$dbname");


$result =  mysql_query("SELECT * from Thirdyr");
$row = mysql_num_rows($result);

// CS2301 fail percentage

$cs2301 = mysql_query("SELECT * from Thirdyr WHERE CS2301 = 'U' AND Regno < 62");


$cs2301f= mysql_num_rows($cs2301);

$cs2301fper = (($cs2301f*100)/132);

// CS2302 fail percentage

$cs2302 = mysql_query("SELECT * from Thirdyr WHERE CS2302 = 'U' AND Regno < 62");


$cs2302f= mysql_num_rows($cs2302);

$cs2302fper = (($cs2302f*100)/132);

// CS2303 fail percentage

$cs2303 = mysql_query("SELECT * from Thirdyr WHERE CS2303 = 'U' AND Regno < 62");


$cs2303f= mysql_num_rows($cs2303);

$cs2303fper = (($cs2303f*100)/132);

// CS2304 fail percentage

$cs2304 = mysql_query("SELECT * from Thirdyr WHERE CS2304 = 'U' AND Regno < 62");


$cs2304f= mysql_num_rows($cs2304);

$cs2304fper = (($cs2304f*100)/132);


// CS2305 fail percentage

$cs2305 = mysql_query("SELECT * from Thirdyr WHERE CS2305 = 'U' AND Regno < 62");


$cs2305f= mysql_num_rows($cs2305);

$cs2305fper = (($cs2305f*100)/132);


// CS2307 fail percentage

$cs2307 = mysql_query("SELECT * from Thirdyr WHERE CS2307 = 'U' AND Regno < 62");


$cs2307f= mysql_num_rows($cs2307);

$cs2307fper = (($cs2307f*100)/132);

// CS2304 fail percentage

$cs2308 = mysql_query("SELECT * from Thirdyr WHERE CS2308 = 'U' AND Regno < 62");


$cs2308f= mysql_num_rows($cs2308);

$cs2308fper = (($cs2308f*100)/132);

// CS2309 fail percentage

$cs2309 = mysql_query("SELECT * from Thirdyr WHERE CS2309 = 'U' AND Regno < 62");


$cs2309f= mysql_num_rows($cs2309);

$cs2309fper = (($cs2309f*100)/132);


// MA2265 fail percentage

$ma2265 = mysql_query("SELECT * from Thirdyr WHERE MA2265 = 'U' AND Regno < 62");


$ma2265f= mysql_num_rows($ma2265);

$ma2265fper = (($ma2265f*100)/132);
 
 echo "The pass results are";
 
 echo "<table border='1'>";
 echo "<tr>";
 echo "<th>CS2301</th><th>CS2302</th><th>CS2303</th><th>CS2304</th><th>CS2305</th><th>CS2307</th><th>CS2308</th><th>CS2309</th><th>MA2265</th>"; echo "</tr>";
 
 echo "<tr>";
 echo "<td>",$row-$cs2301f,"</td><td>",$row-$cs2302f,"</td><td>",$row-$cs2303f,"</td><td>",$row-$cs2304f,"</td><td>",$row-$cs2305f,"</td><td>",$row-$cs2307f,"</td><td>",$row-$cs2308f,"</td><td>",$row-$cs2309f,"</td><td>",$row-$ma2265f,"</td>";
 echo "</tr>";
 echo "</table>";
 
 
 
 
 ?>

</body>
</html>